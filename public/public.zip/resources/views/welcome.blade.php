@extends('layouts.dashboard')

@section('content')

Hello

@endsection
