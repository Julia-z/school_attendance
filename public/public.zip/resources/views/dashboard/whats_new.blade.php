@extends('layouts.dashboard')

@section('content')

<!--                               v1.5                               -->
<!---------------------------------------------------------------------->
<!---------------------------------------------------------------------->

<!--<style>
    ul.emad_vc {
        font-size: large;
    }
</style>-->

<h2>New in version 1.5: </h2>

<ul class="emad_vc">
    <li>Date range in Events table can be arbitrarily large.</li>
    <li>Added what's new feature.</li>
    <li>Volume graph on summary page now displays until 6pm</li>
</ul>

@endsection
